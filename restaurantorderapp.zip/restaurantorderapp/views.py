from django.http import HttpResponse
from django.shortcuts import render
from django.template import loader

from .models import Employee, Customer


def createEmployee(request):
    if request.method == 'POST':
        if request.POST.get('fname') and request.POST.get('lname'):
            post = Employee()
            post.fname = request.POST.get('fname')
            post.lname = request.POST.get('lname')
            post.save()

        return render(request, 'restaurantorderapp/Employee.html')

    else:
        return render(request, 'restaurantorderapp/Employee.html')


def createCustomer(request):
    if request.method == 'POST':
        if request.POST.get('custname') and request.POST.get('address') and request.POST.get('city') and request.POST.get('state') and request.POST.get('zipcode') and request.POST.get('phone'):
            post = Customer()
            post.custname = request.POST.get('custname')
            post.address = request.POST.get('address')
            post.city = request.POST.get('city')
            post.state = request.POST.get('state')
            post.zipcode = request.POST.get('zipcode')
            post.phone = request.POST.get('phone')
            post.save()

        return render(request, 'restaurantorderapp/CustomerPage.html')

    else:
        return render(request, 'restaurantorderapp/CustomerPage.html')